python manage.py runserver localhost:3000

