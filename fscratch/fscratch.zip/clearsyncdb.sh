python manage.py makemigrations --empty home
python manage.py makemigrations
python manage.py migrate