var app = {
    initialize: function() {
        // TODO: put PhoneGap initialization here
        // alert("Hello World!");
    },
};
